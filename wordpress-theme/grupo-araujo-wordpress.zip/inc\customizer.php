<?php
/**
 * Opções do personalizador.
 *
 * @package Grupo_Araujo
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function gat_customize_register( $customizer ) {
	$customizer->add_section(
		'gat_settings',
		array(
			'title'    => __( 'Grupo Araújo - Configurações', 'grupo-araujo' ),
			'priority' => 30,
		)
	);

	$fields = array(
		'gat_whatsapp'        => array( 'WhatsApp com código do país', '5508005757714', 'text' ),
		'gat_atendente'       => array( 'Nome usado nas mensagens', 'equipe', 'text' ),
		'gat_phone'           => array( 'Telefone exibido', '0800 575 7714', 'text' ),
		'gat_cnpj'            => array( 'CNPJ', '67.252.579/0001-50', 'text' ),
		'gat_site'            => array( 'Endereço do site exibido', 'www.grupoaraujotratamentos.com.br', 'text' ),
		'gat_hero_eyebrow'    => array( 'Chamada do banner', 'Atendimento humanizado e acompanhamento especializado', 'text' ),
		'gat_hero_title'      => array( 'Título do banner', 'Grupo Araújo Tratamentos', 'text' ),
		'gat_hero_text'       => array( 'Texto do banner', 'Transformando vidas, restaurando sonhos. Oferecemos acolhimento, orientação e acompanhamento individualizado para pessoas e famílias que buscam apoio em momentos desafiadores.', 'textarea' ),
		'gat_meta_description'=> array( 'Descrição para buscadores', 'Acolhimento, orientação e acompanhamento especializado para pessoas e famílias, com atendimento humanizado 24 horas.', 'textarea' ),
	);

	foreach ( $fields as $id => $field ) {
		$customizer->add_setting(
			$id,
			array(
				'default'           => $field[1],
				'sanitize_callback' => 'textarea' === $field[2] ? 'sanitize_textarea_field' : 'sanitize_text_field',
			)
		);
		$customizer->add_control(
			$id,
			array(
				'label'   => $field[0],
				'section' => 'gat_settings',
				'type'    => $field[2],
			)
		);
	}

	$customizer->add_section(
		'gat_health_plans',
		array(
			'title'       => __( 'Carrossel - Planos de Saúde', 'grupo-araujo' ),
			'description' => __( 'Envie as imagens ou logotipos exibidos no carrossel da página inicial.', 'grupo-araujo' ),
			'priority'    => 31,
		)
	);

	$customizer->add_setting(
		'gat_health_plans_title',
		array(
			'default'           => 'Planos de Saúde',
			'sanitize_callback' => 'sanitize_text_field',
		)
	);
	$customizer->add_control(
		'gat_health_plans_title',
		array(
			'label'   => __( 'Título da seção', 'grupo-araujo' ),
			'section' => 'gat_health_plans',
			'type'    => 'text',
		)
	);

	$customizer->add_setting(
		'gat_health_plans_text',
		array(
			'default'           => 'Consulte nossa equipe para verificar cobertura, disponibilidade e condições de atendimento.',
			'sanitize_callback' => 'sanitize_textarea_field',
		)
	);
	$customizer->add_control(
		'gat_health_plans_text',
		array(
			'label'   => __( 'Texto da seção', 'grupo-araujo' ),
			'section' => 'gat_health_plans',
			'type'    => 'textarea',
		)
	);

	for ( $index = 1; $index <= 12; $index++ ) {
		$setting_id = 'gat_health_plan_image_' . $index;
		$customizer->add_setting(
			$setting_id,
			array(
				'default'           => '',
				'sanitize_callback' => 'esc_url_raw',
			)
		);
		$customizer->add_control(
			new WP_Customize_Image_Control(
				$customizer,
				$setting_id,
				array(
					'label'   => sprintf( __( 'Imagem %d', 'grupo-araujo' ), $index ),
					'section' => 'gat_health_plans',
				)
			)
		);
	}

	$customizer->add_section(
		'gat_latest_posts',
		array(
			'title'    => __( 'Últimas publicações', 'grupo-araujo' ),
			'priority' => 32,
		)
	);
	$customizer->add_setting(
		'gat_latest_posts_title',
		array(
			'default'           => 'Últimas publicações',
			'sanitize_callback' => 'sanitize_text_field',
		)
	);
	$customizer->add_control(
		'gat_latest_posts_title',
		array(
			'label'   => __( 'Título da seção', 'grupo-araujo' ),
			'section' => 'gat_latest_posts',
			'type'    => 'text',
		)
	);
	$customizer->add_setting(
		'gat_latest_posts_count',
		array(
			'default'           => 3,
			'sanitize_callback' => 'absint',
		)
	);
	$customizer->add_control(
		'gat_latest_posts_count',
		array(
			'label'       => __( 'Quantidade de publicações', 'grupo-araujo' ),
			'section'     => 'gat_latest_posts',
			'type'        => 'number',
			'input_attrs' => array( 'min' => 1, 'max' => 6 ),
		)
	);

}
add_action( 'customize_register', 'gat_customize_register' );
